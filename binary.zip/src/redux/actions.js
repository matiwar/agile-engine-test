"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.addTransaction = addTransaction;
exports.ADD_TRANSACTION_SUCCESS = exports.ADD_TRANSACTION = void 0;
var ADD_TRANSACTION = 'ADD_TRANSACTION';
exports.ADD_TRANSACTION = ADD_TRANSACTION;
var ADD_TRANSACTION_SUCCESS = 'ADD_TRANSACTION_SUCCESS';
exports.ADD_TRANSACTION_SUCCESS = ADD_TRANSACTION_SUCCESS;

function addTransactionSuccess(json) {
  return {
    type: ADD_TRANSACTION_SUCCESS,
    payload: json
  };
}

function addTransaction(body) {
  var request = {
    method: 'POST',
    body: JSON.stringify(body),
    headers: {
      'Content-Type': 'application/json'
    }
  };
  return function (dispatch) {
    dispatch({
      type: ADD_TRANSACTION
    });
    return fetch("/api/transactions", request).then(function (response) {
      if (response.ok) {
        return response.json();
      } else {
        throw Error("Request rejected with status ".concat(response.status));
      }
    }).then(function (json) {
      return dispatch(addTransactionSuccess(json));
    });
  };
}