"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _reactRedux = require("react-redux");

var _Accordion = _interopRequireDefault(require("@material-ui/core/Accordion"));

var _AccordionSummary = _interopRequireDefault(require("@material-ui/core/AccordionSummary"));

var _AccordionDetails = _interopRequireDefault(require("@material-ui/core/AccordionDetails"));

var _ExpandMore = _interopRequireDefault(require("@material-ui/icons/ExpandMore"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

var Component = function Component() {
  var account = (0, _reactRedux.useSelector)(function (state) {
    return state.account;
  });
  var transactions = account.transactions;
  return /*#__PURE__*/_react["default"].createElement("div", {
    className: "transactions"
  }, !transactions.length && /*#__PURE__*/_react["default"].createElement("p", null, "No transactions"), transactions.length && /*#__PURE__*/_react["default"].createElement("div", {
    className: "transactions-list"
  }, transactions.map(function (transaction) {
    return /*#__PURE__*/_react["default"].createElement(_Accordion["default"], null, /*#__PURE__*/_react["default"].createElement(_AccordionSummary["default"], {
      expandIcon: /*#__PURE__*/_react["default"].createElement(_ExpandMore["default"], null),
      className: "transaction"
    }, /*#__PURE__*/_react["default"].createElement("span", {
      className: "type ".concat(transaction.type)
    }, transaction.type), /*#__PURE__*/_react["default"].createElement("span", {
      className: "amount"
    }, "$", transaction.amount)), /*#__PURE__*/_react["default"].createElement(_AccordionDetails["default"], {
      className: "details"
    }, /*#__PURE__*/_react["default"].createElement("span", {
      className: "type"
    }, "Type: ", transaction.type), /*#__PURE__*/_react["default"].createElement("span", {
      className: "amount"
    }, "Amount: $", transaction.amount), /*#__PURE__*/_react["default"].createElement("span", {
      className: "date"
    }, "Date: ", transaction.effectiveDate)));
  })));
};

var _default = Component;
exports["default"] = _default;