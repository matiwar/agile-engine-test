"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _reactRedux = require("react-redux");

var _AddTransaction = _interopRequireDefault(require("../AddTransaction"));

var _TransactionsList = _interopRequireDefault(require("../TransactionsList"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

var Component = function Component() {
  var account = (0, _reactRedux.useSelector)(function (state) {
    return state.account;
  });
  var balance = account.balance;
  return /*#__PURE__*/_react["default"].createElement("div", {
    className: "account"
  }, /*#__PURE__*/_react["default"].createElement("h1", {
    className: "account-name"
  }, account.name), /*#__PURE__*/_react["default"].createElement("p", {
    className: "balance"
  }, "( $", balance, " )"), /*#__PURE__*/_react["default"].createElement("div", {
    className: "container"
  }, /*#__PURE__*/_react["default"].createElement(_AddTransaction["default"], null), /*#__PURE__*/_react["default"].createElement(_TransactionsList["default"], null)));
};

var _default = Component;
exports["default"] = _default;