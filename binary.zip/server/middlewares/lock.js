"use strict";

var _AccountRepository = _interopRequireDefault(require("../repositories/AccountRepository"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

module.exports = function (req, res, next) {
  var account = _AccountRepository["default"].getAccount(1);

  req.account = account;

  if (account.locked) {
    res.status(423).send({
      message: 'Another transaction is being processed'
    });
  } else {
    next();
  }
};