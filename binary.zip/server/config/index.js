"use strict";

var config = {
  port: 3001
};
module.exports = config;