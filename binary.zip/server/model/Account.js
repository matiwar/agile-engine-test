"use strict";

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

var Account = /*#__PURE__*/function () {
  function Account(id, name, balance) {
    _classCallCheck(this, Account);

    this.id = id;
    this.name = name;
    this.balance = balance;
    this.transactions = [];
    this.locked = false;
  }

  _createClass(Account, [{
    key: "addTransaction",
    value: function addTransaction(transaction) {
      this.updateBalance(transaction);
      this.transactions.push(transaction);
    }
  }, {
    key: "updateBalance",
    value: function updateBalance(transaction) {
      var type = transaction.type,
          amount = transaction.amount;
      var newBalance = this.balance;

      switch (type) {
        case 'DEBIT':
          newBalance = newBalance - amount;

          if (newBalance < 0) {
            throw new Error("Account balance can't be lower than 0");
          }

          break;

        case 'CREDIT':
          newBalance = newBalance + amount;
          break;

        default:
          throw new Error("Invalid transaction type");
      }

      this.balance = newBalance;
    }
  }, {
    key: "changeLocked",
    value: function changeLocked(value) {
      this.locked = value;
    }
  }]);

  return Account;
}();

module.exports = Account;