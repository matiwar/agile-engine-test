"use strict";

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var Transaction = function Transaction(type, amount) {
  _classCallCheck(this, Transaction);

  if (amount <= 0) {
    throw new Error("Transaction amount must be greater than 0");
  }

  this.effectiveDate = new Date().toString();
  this.type = type;
  this.amount = amount;
};

module.exports = Transaction;