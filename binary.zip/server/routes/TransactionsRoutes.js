"use strict";

var _coRouter = _interopRequireDefault(require("co-router"));

var _lock = _interopRequireDefault(require("../middlewares/lock"));

var _TransactionsService = _interopRequireDefault(require("../services/TransactionsService"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

var router = (0, _coRouter["default"])();
var locked = false;
router.get('/', _lock["default"], function (req, res) {
  var response = _TransactionsService["default"].getTransactions();

  res.status(200).json(response);
});
router.get('/balance', _lock["default"], function (req, res) {
  var response = _TransactionsService["default"].getBalance();

  res.status(200).json(response);
});
router.post('/', _lock["default"], function (req, res, next) {
  var _req$body = req.body,
      type = _req$body.type,
      amount = _req$body.amount;

  var response = _TransactionsService["default"].addTransaction(type, amount);

  res.status(200).json(response);
});
module.exports = router;