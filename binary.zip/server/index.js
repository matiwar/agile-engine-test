"use strict";

var _express = _interopRequireDefault(require("express"));

var _path = _interopRequireDefault(require("path"));

var _fs = _interopRequireDefault(require("fs"));

var _view2 = _interopRequireDefault(require("../src/view"));

var _config = _interopRequireDefault(require("./config"));

var _AccountRepository = _interopRequireDefault(require("./repositories/AccountRepository"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

require("@babel/register");

var app = (0, _express["default"])();

var router = _express["default"].Router();

var initialState = {
  account: _AccountRepository["default"].getAccount(1)
};

var serverRenderer = function serverRenderer(req, res, next) {
  var _view = (0, _view2["default"])(initialState),
      preloadedState = _view.preloadedState,
      content = _view.content;

  _fs["default"].readFile(_path["default"].resolve('../src/public/index.html'), 'utf8', function (err, data) {
    if (err) {
      return res.status(500).send('An error occurred');
    }

    return res.send(data.replace('<div id="root"></div>', "<div id=\"root\">".concat(content, "</div>")).replace('<script></script>', "<script>window.__STATE__ = ".concat(JSON.stringify(preloadedState), "</script>")));
  });
};

app.use('/assets', _express["default"]["static"](_path["default"].resolve(__dirname, '../assets')));
router.use('^/$', serverRenderer);
router.use('/api', require('./routes'));
router.use('/ping', require('express-healthcheck')());
app.use(_express["default"].json());
app.use(_express["default"].urlencoded({
  extended: false
}));
app.use(router);
app.listen(_config["default"].port, function () {
  console.log("Server running on port ".concat(_config["default"].port));
});