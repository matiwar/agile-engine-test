"use strict";

var _Account = _interopRequireDefault(require("../model/Account"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

var account;

function createAccount(name, balance) {
  account = new _Account["default"](1, name, balance);
  return account;
}

function getAccount(id) {
  return account || createAccount('Test account', 0);
}

function addTransaction(transaction) {
  account.addTransaction(transaction);
  return {
    transaction: transaction
  };
}

module.exports = {
  createAccount: createAccount,
  getAccount: getAccount,
  addTransaction: addTransaction
};