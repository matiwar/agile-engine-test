"use strict";

var _winston = require("winston");

var _moment = _interopRequireDefault(require("moment"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

var timestamp = function timestamp() {
  return (0, _moment["default"])().format('YYYY/MM/DD HH:mm:ss');
};

var combine = _winston.format.combine,
    printf = _winston.format.printf;
var myFormat = printf(function (info) {
  return "".concat(timestamp(), " [").concat(info.level.toUpperCase(), "]: ").concat(info.message);
});
var customFormat = combine(myFormat);
var logger = (0, _winston.createLogger)({
  level: 'info',
  format: customFormat,
  transports: [new _winston.transports.Console()]
});
module.exports = logger;