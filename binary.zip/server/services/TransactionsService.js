"use strict";

var _AccountRepository = _interopRequireDefault(require("../repositories/AccountRepository"));

var _Transaction = _interopRequireDefault(require("../model/Transaction"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function getBalance() {
  var account = _AccountRepository["default"].getAccount(1);

  return {
    balance: account.balance
  };
}

function getTransactions() {
  var account = _AccountRepository["default"].getAccount(1);

  return {
    transactions: account.transactions
  };
}

function addTransaction(type, amount) {
  var account = _AccountRepository["default"].getAccount(1);

  account.changeLocked(true);

  try {
    var transaction = new _Transaction["default"](type, amount);
    account.addTransaction(transaction);
    account.changeLocked(false);
    return {
      account: account
    };
  } catch (err) {
    account.changeLocked(false);
    throw err;
  }
}

module.exports = {
  getBalance: getBalance,
  getTransactions: getTransactions,
  addTransaction: addTransaction
};